export var Global = {   
    mobileNumber:'',
    otp:'',
    url: 'http://localhost:5000/',//Localhost

 }